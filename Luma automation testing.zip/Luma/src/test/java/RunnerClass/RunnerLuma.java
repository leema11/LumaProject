package RunnerClass;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import baseClass.baseLuma;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions (features = "src\\test\\java\\Luma\\Luma.feature",glue = "stepClass",dryRun = false)


public class RunnerLuma extends baseLuma{
	
		@BeforeClass
		public static void start() {
			BrowserLanuch();
			maximise();
		}
		@AfterClass
		public static void end() {
			
		}
}
