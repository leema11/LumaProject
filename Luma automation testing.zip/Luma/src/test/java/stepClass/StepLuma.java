package stepClass;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import baseClass.baseLuma;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pomClass.pomLuma;

public class StepLuma extends baseLuma {

	pomLuma pom = new pomLuma();

	@Given("user on the login page")
	public void user_on_the_login_page() {
		
		implicityWait();
		
		getURL("https://magento.softwaretestingboard.com/");

		driver.findElement(pom.clickSignIn).click();

	}

	@When("user enter a valid email and password")
	public void user_enter_a_valid_email_and_password() {
		
		driver.findElement(pom.enterEmail).sendKeys("leemaglory8@gmail.com");

		driver.findElement(pom.enterPAssword).sendKeys("Leemaglory8");

		driver.findElement(pom.clickSigInBtn).click();
		
	}

	@Then("user click the push it messenger bag")
	public void user_click_the_push_it_messenger_bag() {
		
		implicityWait();
		WebElement scrlDn = driver.findElement(pom.clickBag);
		jsScroll(scrlDn);

		Actions action = new Actions(driver);
		action.moveToElement(scrlDn).perform();

		driver.findElement(pom.AddToComp).click();

		
	}

	@Then("user click the add to compare bottun")
	public void user_click_the_add_to_compare_bottun() {
		
		implicityWait();
		driver.findElement(pom.clickList).click();

//			driver.findElement(pom.clickPrintbtn).click();
//			driver.switchTo().alert().accept();
//			Set<String> windowHandle = driver.getWindowHandles();
//			List<String> window = new ArrayList<String>(windowHandle);
//			System.out.println(window);
//			driver.switchTo().window(window.get(1));
//			driver.findElement(pom.)
		
	}
	
	
	@Then("user click the compartion list and Add to cart & add to wishlist")
	public void user_click_the_compartion_list_and_add_to_cart_add_to_wishlist() {
		
		implicityWait();
		driver.findElement(pom.AddToCart).click();

		driver.findElement(pom.AddToWish).click();

//			driver.findElement(pom.remove).click();
//			driver.findElement(pom.removeOK).click();

	}

	
	@When("User click the Cart and Edit botton")
	public void user_click_the_cart_and_edit_botton() {

		implicityWait();

		driver.findElement(pom.cart).click();

		driver.findElement(pom.edit).click();

	}

	@When("Click the Update , Assert the product value and Subtotal value")
	public void click_the_update_assert_the_product_value_and_subtotal_value() {

		implicityWait();

		driver.findElement(pom.update).click();

		try {

			String cartAmt = driver.findElement(pom.cartAmt).getText();

			System.out.println(cartAmt);

			String subTotal = driver.findElement(pom.subtotal).getText();

			System.out.println(subTotal);

			if (cartAmt == subTotal) {
				System.out.println("Its Equal");
			} else {
				System.out.println("Its not Equal");
			}
		} catch (Exception e) {
		}

	}

	@When("Click the checkout page and Assert the same page")
	public void click_the_checkout_page_and_assert_the_same_page() {

		implicityWait();

		driver.findElement(pom.checkout).click();

		try {
			implicityWait();

			String finalPage = "Shipping Address";

			String shipping = driver.findElement(pom.finalPage).getText();

			Assert.assertEquals(finalPage, shipping);

			System.out.println("This is correct Page");

		} catch (Exception e) {
			System.out.println("This is Not correct Page");
		}
		implicityWait();

		driver.navigate().back();

		driver.findElement(pom.cart).click();

		driver.findElement(pom.deleteItem).click();

		driver.findElement(pom.clickOK).click();

	}

	@When("Goto Home page  and Logout the account")
	public void goto_home_page_and_logout_the_account() {

		implicityWait();

		for (int i = 0; i < 8; i++) {
			driver.navigate().back();
		}
	}

}
